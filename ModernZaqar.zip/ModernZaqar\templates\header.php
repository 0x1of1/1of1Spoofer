            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($currentPage === 'main') ? 'active' : ''; ?>" href="index.php">
                            <i class="fas fa-envelope"></i> Email
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($currentPage === 'raw_email') ? 'active' : ''; ?>" href="index.php?page=raw_email">
                            <i class="fas fa-code"></i> Raw Email Mode
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($currentPage === 'domain') ? 'active' : ''; ?>" href="index.php?page=domain">
                            <i class="fas fa-globe"></i> Domain Lookup
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($currentPage === 'smtp') ? 'active' : ''; ?>" href="index.php?page=smtp">
                            <i class="fas fa-server"></i> SMTP
                        </a>
                    </li>
                </ul>
            </div> 