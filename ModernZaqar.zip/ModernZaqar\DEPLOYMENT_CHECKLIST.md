# Modern Zaqar Deployment Checklist

Use this checklist to ensure Modern Zaqar is deployed and functioning correctly.

## Pre-Deployment Checks

- [ ] PHP version 8.0 or higher is installed
- [ ] Required PHP extensions are available:
  - [ ] json
  - [ ] fileinfo
  - [ ] curl
  - [ ] mbstring
- [ ] Web server (Apache/Nginx) is properly configured
- [ ] Email sending method is available (SMTP/API/mail())
- [ ] Appropriate permissions are set on directories:
  - [ ] logs/ directory is writable
  - [ ] uploads/ directory is writable

## Docker Deployment Checks

- [ ] docker-compose.yml is properly configured
- [ ] Docker and Docker Compose are installed
- [ ] Container builds successfully with `docker-compose build`
- [ ] Container starts successfully with `docker-compose up -d`
- [ ] Web application is accessible at http://localhost:8080 (or configured port)

## Application Functionality Checks

- [ ] Main interface loads without errors
- [ ] Domain analysis tool works correctly
  - [ ] SPF record check works
  - [ ] DMARC record check works
  - [ ] MX record check works
- [ ] Email spoofing functionality works
  - [ ] Form submission works
  - [ ] Email delivery is successful
  - [ ] Attachments can be uploaded and sent
- [ ] Email templates can be loaded and used

## Security Checks

- [ ] CSRF protection is working
- [ ] Rate limiting is functioning
- [ ] File upload validation works correctly
- [ ] Input sanitation is active

## Error Handling Checks

- [ ] Application handles invalid inputs gracefully
- [ ] Logging works correctly
  - [ ] Check logs/ directory for log files
  - [ ] Ensure logs contain appropriate information
- [ ] Error display is disabled in production

## Network and Connectivity Checks

- [ ] DNS resolution is working
- [ ] SMTP server is reachable (if using SMTP)
- [ ] API endpoints are accessible (if using SendGrid/Mailgun)

## Common Troubleshooting Steps

If you encounter issues, try these steps:

1. **PHP Fatal Errors**:

   - Check for function redeclarations
   - Ensure all PHP files use `function_exists()` checks
   - Verify that files aren't included multiple times

2. **Email Sending Failures**:

   - Verify SMTP credentials
   - Check that the sending method is properly configured
   - Test connection to SMTP server or API endpoint

3. **Permission Issues**:

   - Ensure logs/ and uploads/ directories are writable
   - Check web server user permissions

4. **Docker Issues**:

   - Rebuild container with `docker-compose down && docker-compose build && docker-compose up -d`
   - Check Docker logs with `docker-compose logs`
   - Verify port mappings are correct

5. **Domain Analysis Issues**:
   - Ensure PHP has permission to perform DNS lookups
   - Verify that required DNS record types can be queried

## Post-Deployment Verification

- [ ] Send test email to verify full functionality
- [ ] Check logs for any warnings or errors
- [ ] Test domain analysis on known domains
- [ ] Verify that all UI elements work correctly
