<?php

/**
 * Modern Zaqar - Configuration File
 * 
 * This file contains all the configuration settings for the Modern Zaqar email spoofer tool.
 * Modify these settings to suit your environment and requirements.
 * 
 * WARNING: This tool is for educational purposes and authorized penetration testing only.
 * Misuse may violate laws regarding unauthorized access to computer systems.
 */

// Load environment variables
require_once __DIR__ . '/includes/env.php';

// Application settings
$config = [
    // General settings
    'app_name' => '1of1spoofer',
    'version' => '2.0.0',
    'debug_mode' => true,
    'timezone' => env('TIMEZONE', 'UTC'), // Set your timezone

    // Email sending method: only 'smtp' is supported
    'send_method' => 'smtp', // Force SMTP as the only sending method

    // PHP mail() function settings (only used if send_method is 'mail')
    'mail' => [
        'use_return_path' => true,
        'return_path' => '', // Return-Path header, leave empty to use From address
    ],

    // SMTP server settings (only used if send_method is 'smtp')
    'smtp' => [
        'host' => 'lessonsdrivingschool.co.uk',
        'port' => 587,
        'encryption' => 'tls',
        'username' => 'unbiased@lessonsdrivingschool.co.uk',
        'password' => '60_horos$co7E!_pe', // Raw password (PHP strings handle $ fine)
        'verify_ssl' => false,
        'debug_level' => 4 // Maximum debug level to see what's happening
    ],

    // SendGrid API settings (only used if send_method is 'sendgrid')
    'sendgrid' => [
        'api_key' => env('SENDGRID_API_KEY', 'your_sendgrid_key'),
    ],

    // Mailgun API settings (only used if send_method is 'mailgun')
    'mailgun' => [
        'api_key' => env('MAILGUN_API_KEY', 'your_mailgun_key'),
        'domain' => env('MAILGUN_DOMAIN', 'your_mailgun_domain'),
    ],

    // File upload settings
    'uploads' => [
        'enabled' => true, // Set to false to disable file uploads
        'dir' => __DIR__ . '/uploads',
        'max_size' => 10 * 1024 * 1024, // 10MB
        'allowed_types' => [
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'txt' => 'text/plain'
        ],
        'scan_uploads' => true, // Basic content validation
    ],

    // Security settings
    'security' => [
        'csrf_protection' => env('CSRF_PROTECTION', true),
        'rate_limit' => [
            'enabled' => true,
            'max_emails' => env('RATE_LIMIT_EMAILS', 50),
            'window' => env('RATE_LIMIT_WINDOW', 3600) // Default: 1 hour in seconds
        ],
        'ip_tracking' => true,
        'require_ethical_agreement' => true
    ],

    // Logging settings
    'logging' => [
        'enabled' => true,
        'level' => 'debug',  // debug, info, warning, error
        'dir' => __DIR__ . '/logs',
        'file_format' => 'Y-m-d', // Date format for log files
        'log_path' => __DIR__ . '/logs/app.log',
        'max_log_size' => 5 * 1024 * 1024, // 5MB
    ],

    // Domain security analyzer settings
    'analyzer' => [
        'enabled' => true,
        'check_spf' => true,
        'check_dkim' => true,
        'check_dmarc' => true,
        'dns_timeout' => 5 // seconds
    ],

    // UI settings
    'ui' => [
        'theme' => env('DEFAULT_THEME', 'light'), // light, dark, or auto
        'rich_text_editor' => true,
        'show_template_library' => true,
        'default_language' => 'en', // en, es, fr, etc.
        'allow_attachments' => false,  // Feature not implemented yet
    ]
];

/**
 * Function to get configuration value
 *
 * @param string $key The configuration key to retrieve
 * @param mixed $default The default value to return if key not found
 * @return mixed The configuration value
 */
function config($key, $default = null)
{
    global $config;

    // Start session if not already started
    if (!isset($_SESSION) && !headers_sent()) {
        session_start();
    }

    // Check for custom settings in session (e.g., user-defined SMTP settings)
    if (isset($_SESSION['custom_settings'])) {
        // Handle nested keys like 'smtp.host'
        if (strpos($key, '.') !== false) {
            $parts = explode('.', $key);

            // Check if the main setting type exists in session (e.g., 'smtp')
            if (isset($_SESSION['custom_settings'][$parts[0]])) {
                // Check if the specific setting exists (e.g., 'host')
                if (isset($_SESSION['custom_settings'][$parts[0]][$parts[1]])) {
                    return $_SESSION['custom_settings'][$parts[0]][$parts[1]];
                }
            }
        }
    }

    // Handle nested keys like 'smtp.host'
    if (strpos($key, '.') !== false) {
        $parts = explode('.', $key);
        $value = $config;

        foreach ($parts as $part) {
            if (!isset($value[$part])) {
                return $default;
            }
            $value = $value[$part];
        }

        return $value;
    }

    return isset($config[$key]) ? $config[$key] : $default;
}

// Set the timezone
date_default_timezone_set(config('timezone', 'UTC'));

// Initialize logging directory if it doesn't exist
if (config('logging.enabled', true)) {
    $logDir = config('logging.dir', __DIR__ . '/logs');
    if (!file_exists($logDir)) {
        mkdir($logDir, 0777, true);
    }
}

// Initialize uploads directory if it doesn't exist
if (config('uploads.enabled', true)) {
    $uploadDir = config('uploads.dir', __DIR__ . '/uploads');
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
}
