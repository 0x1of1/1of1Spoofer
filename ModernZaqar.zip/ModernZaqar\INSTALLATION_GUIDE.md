# Modern Zaqar: Installation & Usage Guide

This document provides detailed instructions for setting up and using the Modern Zaqar email spoofing tool on a Linux VPS server.

## Table of Contents

1. [Requirements](#requirements)
2. [VPS Setup](#vps-setup)
3. [Software Installation](#software-installation)
4. [Modern Zaqar Installation](#modern-zaqar-installation)
5. [Server Configuration](#server-configuration)
6. [Email Configuration](#email-configuration)
7. [Security Considerations](#security-considerations)
8. [Usage Guide](#usage-guide)
9. [Troubleshooting](#troubleshooting)
10. [Legal Considerations](#legal-considerations)

## Requirements

### Minimum System Requirements

- Linux VPS (Ubuntu 20.04/22.04 LTS recommended)
- 1GB RAM (2GB recommended)
- 1 CPU core
- 25GB storage
- Root access or sudo privileges

### Software Requirements

- Apache2 or Nginx web server
- PHP 8.0 or higher
- Required PHP extensions: json, curl, fileinfo, mbstring, xml, zip
- Composer (PHP dependency manager)
- Git (optional, for cloning repository)

## VPS Setup

1. **Connect to your VPS** via SSH:

   ```bash
   ssh username@your_server_ip
   ```

2. **Update system packages**:

   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

3. **Configure timezone** (optional):
   ```bash
   sudo timedatectl set-timezone Your/Timezone
   ```

## Software Installation

### Install Apache and PHP

```bash
sudo apt install apache2 php php-cli php-fpm php-json php-common php-mysql php-zip php-gd php-mbstring php-curl php-xml php-pear php-bcmath git unzip -y
```

### Verify PHP Version

```bash
php -v
```

Ensure the output shows PHP 8.0 or higher.

### Enable Required Apache Modules

```bash
sudo a2enmod rewrite headers
sudo systemctl restart apache2
```

### Install Composer

```bash
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
sudo chmod +x /usr/local/bin/composer
```

## Modern Zaqar Installation

### Create Web Directory

```bash
sudo mkdir -p /var/www/modern-zaqar
sudo chown -R www-data:www-data /var/www/modern-zaqar
sudo chmod -R 755 /var/www/modern-zaqar
```

### Deploy Modern Zaqar

**Option 1: Clone from Git repository**

```bash
cd /var/www/modern-zaqar
sudo git clone https://github.com/yourusername/modern-zaqar.git .
```

**Option 2: Upload files via SFTP**
Use an SFTP client like FileZilla to upload files to `/var/www/modern-zaqar`

### Install Dependencies

```bash
cd /var/www/modern-zaqar
sudo composer install
```

### Set Proper Permissions

```bash
sudo chmod -R 755 /var/www/modern-zaqar
sudo chmod -R 777 /var/www/modern-zaqar/logs
sudo chmod -R 777 /var/www/modern-zaqar/uploads
sudo chown -R www-data:www-data /var/www/modern-zaqar
```

## Server Configuration

### Configure Apache Virtual Host

1. **Create a virtual host file**:

   ```bash
   sudo nano /etc/apache2/sites-available/modern-zaqar.conf
   ```

2. **Add the following configuration**:

   ```apache
   <VirtualHost *:80>
       ServerAdmin webmaster@localhost
       ServerName your-domain.com
       ServerAlias www.your-domain.com
       DocumentRoot /var/www/modern-zaqar

       <Directory /var/www/modern-zaqar>
           Options -Indexes +FollowSymLinks
           AllowOverride All
           Require all granted
       </Directory>

       ErrorLog ${APACHE_LOG_DIR}/modern-zaqar-error.log
       CustomLog ${APACHE_LOG_DIR}/modern-zaqar-access.log combined
   </VirtualHost>
   ```

   Replace `your-domain.com` with your actual domain or use the server's IP if you don't have a domain.

3. **Enable the site and restart Apache**:
   ```bash
   sudo a2ensite modern-zaqar.conf
   sudo systemctl restart apache2
   ```

### Configure Firewall

```bash
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

## Email Configuration

Modern Zaqar supports three email sending methods. Choose the one that best fits your needs:

### Option 1: SMTP Server (Recommended)

1. **Edit the configuration file**:

   ```bash
   sudo nano /var/www/modern-zaqar/config.php
   ```

2. **Configure SMTP settings**:

   ```php
   // Set send_method to 'smtp'
   'send_method' => 'smtp',

   // Configure SMTP settings
   'smtp' => [
       'host' => 'smtp.gmail.com', // Or your preferred SMTP provider
       'port' => 587,
       'secure' => 'tls',
       'auth' => true,
       'username' => 'your-email@gmail.com', // Your SMTP username
       'password' => 'your-app-password', // Your SMTP password
       'debug' => 0
   ],
   ```

   **Gmail SMTP Note**: If using Gmail, you need to:

   - Enable 2-Step Verification
   - Generate an App Password
   - Use this App Password in the config

### Option 2: PHP mail() Function

1. **Install Postfix**:

   ```bash
   sudo apt install postfix -y
   ```

2. **Choose "Internet Site" during installation**

3. **Set your domain name when prompted**

4. **Edit the configuration file**:

   ```bash
   sudo nano /var/www/modern-zaqar/config.php
   ```

5. **Configure mail settings**:
   ```php
   // Set send_method to 'mail'
   'send_method' => 'mail',
   ```

### Option 3: Email APIs

1. **Edit the configuration file**:

   ```bash
   sudo nano /var/www/modern-zaqar/config.php
   ```

2. **Configure API settings**:

   ```php
   // Set send_method to 'api'
   'send_method' => 'api',

   // Configure API settings
   'api' => [
       'service' => 'sendgrid', // Options: 'sendgrid', 'mailgun'
       'key' => 'your_api_key',
       'domain' => 'your_domain' // Required for Mailgun
   ],
   ```

## Security Considerations

### Server Hardening

1. **Disable root SSH login**:

   ```bash
   sudo nano /etc/ssh/sshd_config
   ```

   Find and change `PermitRootLogin yes` to `PermitRootLogin no`

   ```bash
   sudo systemctl restart sshd
   ```

2. **Implement fail2ban** to protect against brute force attacks:
   ```bash
   sudo apt install fail2ban -y
   sudo systemctl enable fail2ban
   sudo systemctl start fail2ban
   ```

### Set Up TLS/SSL (HTTPS)

1. **Install Certbot**:

   ```bash
   sudo apt install certbot python3-certbot-apache -y
   ```

2. **Obtain and install SSL certificate**:
   ```bash
   sudo certbot --apache -d your-domain.com -d www.your-domain.com
   ```

## Usage Guide

### Accessing the Application

Open your web browser and navigate to your domain or server IP:

```
https://your-domain.com/
```

or

```
http://your-server-ip/
```

### Email Spoofing Steps

1. **Access the web interface** through your browser

2. **Fill in the email form**:

   - **From Name**: The display name that will appear
   - **From Email**: The email address being spoofed
   - **To Email**: The recipient's email address
   - **Subject**: The email subject line
   - **Content**: The body of the email (rich text editor available)
   - **Attachments**: Optional files to attach

3. **Select your sending method** (mail, SMTP, or API)

4. **Check the ethical usage agreement** box

5. **Send the test email** and review the delivery report

### Domain Analysis

1. Enter a domain in the "Check Domain Security" section
2. Click "Analyze" to examine the domain's email security posture
3. Review the results to determine if the domain is likely to be spoofable

### Email Templates

1. Click the "Load Template" button
2. Select a pre-made template (password reset, account verification, etc.)
3. Customize the template as needed
4. Send the email

## Troubleshooting

### Common Issues and Solutions

#### Emails Not Sending

1. **Check PHP mail logs**:

   ```bash
   sudo tail -f /var/log/mail.log
   ```

2. **Verify SMTP credentials** if using SMTP method

3. **Check file permissions**:

   ```bash
   sudo chmod -R 777 /var/www/modern-zaqar/logs
   sudo chmod -R 777 /var/www/modern-zaqar/uploads
   ```

4. **Examine error logs**:
   ```bash
   sudo tail -f /var/log/apache2/modern-zaqar-error.log
   ```

#### 500 Internal Server Error

1. **Check Apache error logs**:

   ```bash
   sudo tail -f /var/log/apache2/error.log
   ```

2. **Verify PHP version and extensions**:

   ```bash
   php -v
   php -m
   ```

3. **Check file permissions**:
   ```bash
   sudo chown -R www-data:www-data /var/www/modern-zaqar
   sudo chmod -R 755 /var/www/modern-zaqar
   ```

#### Emails Going to Spam

1. **Configure SPF, DKIM, and DMARC** records for your sending domain

2. **Use a reputable SMTP provider** instead of PHP mail()

3. **Warm up your email sending IP** gradually before sending bulk emails

## Legal Considerations

### Ethical Usage

This tool is provided for **EDUCATIONAL PURPOSES ONLY**. Email spoofing can be illegal if used without explicit permission from the target organization.

This tool should only be used:

1. During authorized penetration testing engagements
2. For security awareness training
3. To test your own organization's email security controls

**By using this software, you agree to use it responsibly and legally.**

## Updates and Maintenance

### Keeping Modern Zaqar Updated

1. **Check for updates**:

   ```bash
   cd /var/www/modern-zaqar
   git pull origin main
   ```

2. **Update dependencies**:
   ```bash
   cd /var/www/modern-zaqar
   composer update
   ```

---

This installation guide was last updated on March 20, 2024.
