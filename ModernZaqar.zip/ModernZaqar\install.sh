#!/bin/bash

# Modern Zaqar Installation Script
# This script automates the installation of Modern Zaqar on a fresh Linux server

# Color definitions
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print banner
echo -e "${BLUE}"
echo "╔════════════════════════════════════════════╗"
echo "║ Modern Zaqar - Email Spoofing Tool Install ║"
echo "╚════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running as root
if [ "$(id -u)" != "0" ]; then
   echo -e "${RED}[ERROR] This script must be run as root${NC}" 1>&2
   echo -e "${YELLOW}Try:${NC} sudo bash $0" 1>&2
   exit 1
fi

# Confirm installation
echo -e "${YELLOW}This script will install Modern Zaqar and its dependencies.${NC}"
echo -e "${YELLOW}This tool is for EDUCATIONAL PURPOSES ONLY.${NC}"
echo -e "${YELLOW}Continue? (y/n)${NC}"
read -r confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo -e "${RED}Installation aborted.${NC}"
    exit 1
fi

# Function to display progress
function progress() {
    echo -e "${GREEN}[+] $1${NC}"
}

# Function to display errors
function error() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

# Check system
progress "Checking system..."
if [ -f /etc/os-release ]; then
    . /etc/os-release
    if [[ "$ID" != "ubuntu" && "$ID" != "debian" ]]; then
        error "This script is designed for Ubuntu/Debian. Your system: $ID"
    fi
else
    error "Cannot determine OS type"
fi

# Update system packages
progress "Updating system packages..."
apt update || error "Failed to update package list"
apt upgrade -y || error "Failed to upgrade packages"

# Install required packages
progress "Installing required packages..."
apt install -y apache2 php php-cli php-fpm php-json php-common php-mysql php-zip php-gd php-mbstring php-curl php-xml php-pear php-bcmath git unzip || error "Failed to install required packages"

# Check PHP version
php_version=$(php -r 'echo PHP_VERSION;')
if [[ $(echo "$php_version" | cut -d. -f1) -lt 8 ]]; then
    error "PHP 8.0+ is required. Detected: $php_version"
fi

# Enable Apache modules
progress "Configuring Apache..."
a2enmod rewrite headers || error "Failed to enable Apache modules"
systemctl restart apache2 || error "Failed to restart Apache"

# Install Composer
progress "Installing Composer..."
curl -sS https://getcomposer.org/installer | php || error "Failed to download Composer"
mv composer.phar /usr/local/bin/composer || error "Failed to install Composer"
chmod +x /usr/local/bin/composer || error "Failed to set Composer permissions"

# Set up installation directory
progress "Setting up installation directory..."
install_dir="/var/www/html/modern-zaqar"
mkdir -p "$install_dir" || error "Failed to create installation directory"

# Clone or download Modern Zaqar
progress "Downloading Modern Zaqar..."
# Option 1: If this script is part of the package, copy files
if [ -f "$(dirname "$0")/index.php" ]; then
    cp -r "$(dirname "$0")"/* "$install_dir/" || error "Failed to copy files"
# Option 2: Clone from git (replace with actual repository)
else
    # This is a placeholder - replace with actual repository
    git clone https://github.com/yourusername/modern-zaqar.git "$install_dir" || error "Failed to clone repository"
fi

# Install dependencies
progress "Installing dependencies..."
cd "$install_dir" || error "Failed to change to installation directory"
composer install --no-dev || error "Failed to install dependencies"

# Set permissions
progress "Setting file permissions..."
chmod -R 755 "$install_dir" || error "Failed to set directory permissions"
chmod -R 777 "$install_dir/logs" "$install_dir/uploads" || error "Failed to set logs/uploads permissions"
chown -R www-data:www-data "$install_dir" || error "Failed to set ownership"

# Configure Apache virtual host
progress "Configuring Apache virtual host..."
cat > /etc/apache2/sites-available/modern-zaqar.conf << EOF
<VirtualHost *:80>
    ServerAdmin webmaster@localhost
    DocumentRoot $install_dir
    
    <Directory $install_dir>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog \${APACHE_LOG_DIR}/modern-zaqar-error.log
    CustomLog \${APACHE_LOG_DIR}/modern-zaqar-access.log combined
</VirtualHost>
EOF

# Enable site
a2ensite modern-zaqar.conf || error "Failed to enable Apache site"
systemctl reload apache2 || error "Failed to reload Apache"

# Configure SMTP (optional)
echo -e "${YELLOW}Would you like to configure SMTP settings now? (y/n)${NC}"
read -r setup_smtp
if [[ "$setup_smtp" == "y" || "$setup_smtp" == "Y" ]]; then
    echo -e "${YELLOW}Enter SMTP host (e.g., smtp.gmail.com):${NC}"
    read -r smtp_host
    echo -e "${YELLOW}Enter SMTP port (e.g., 587):${NC}"
    read -r smtp_port
    echo -e "${YELLOW}Enter SMTP username:${NC}"
    read -r smtp_user
    echo -e "${YELLOW}Enter SMTP password:${NC}"
    read -rs smtp_pass
    echo
    
    # Extract config.php content
    config_content=$(cat "$install_dir/config.php")
    
    # Replace SMTP settings
    config_content=$(echo "$config_content" | sed "s/'send_method' => 'mail'/'send_method' => 'smtp'/g")
    config_content=$(echo "$config_content" | sed "s/'host' => 'smtp.example.com'/'host' => '$smtp_host'/g")
    config_content=$(echo "$config_content" | sed "s/'port' => 587/'port' => $smtp_port/g")
    config_content=$(echo "$config_content" | sed "s/'username' => 'your_username'/'username' => '$smtp_user'/g")
    config_content=$(echo "$config_content" | sed "s/'password' => 'your_password'/'password' => '$smtp_pass'/g")
    
    # Write back to config.php
    echo "$config_content" > "$install_dir/config.php"
    progress "SMTP configuration updated"
fi

# Get server IP
server_ip=$(hostname -I | awk '{print $1}')

# Installation complete
echo -e "${GREEN}==================================================${NC}"
echo -e "${GREEN}Modern Zaqar has been successfully installed!${NC}"
echo -e "${GREEN}==================================================${NC}"
echo
echo -e "${BLUE}Access the application at:${NC}"
echo -e "${YELLOW}http://$server_ip/modern-zaqar/${NC}"
echo
echo -e "${BLUE}Documentation:${NC}"
echo -e "${YELLOW}- Installation Guide: $install_dir/INSTALLATION_GUIDE.md${NC}"
echo -e "${YELLOW}- Domain Analysis Guide: $install_dir/DOMAIN_ANALYSIS_GUIDE.md${NC}"
echo -e "${YELLOW}- Quick Start: $install_dir/QUICK_START.md${NC}"
echo
echo -e "${RED}REMEMBER: This tool is for EDUCATIONAL PURPOSES ONLY.${NC}"
echo -e "${RED}Email spoofing without authorization is illegal.${NC}"
echo

exit 0 