# Modern Zaqar Quick Start Guide

This guide will help you get Modern Zaqar up and running as quickly as possible.

## Prerequisites

- Linux VPS with root access (Ubuntu 20.04+ or Debian 11+ recommended)
- Domain name (optional but recommended)
- Basic knowledge of Linux commands

## Option 1: One-Command Installation (Ubuntu/Debian)

For a completely automated setup on Ubuntu or Debian systems, you can use our installation script:

```bash
curl -s https://raw.githubusercontent.com/yourusername/modern-zaqar/main/install.sh | sudo bash
```

> ⚠️ **Note**: Always review scripts before executing them with root privileges. You can download and inspect the script first:
>
> ```bash
> curl -s https://raw.githubusercontent.com/yourusername/modern-zaqar/main/install.sh > install.sh
> cat install.sh
> sudo bash install.sh
> ```

## Option 2: 5-Minute Manual Setup

If you prefer a manual installation or are using another Linux distribution, follow these steps:

### A. Install required packages

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y apache2 php php-cli php-json php-common php-mysql php-zip php-gd php-mbstring php-curl php-xml php-bcmath git unzip

# Check PHP version (should be 8.0+)
php -v

# Enable required Apache modules
sudo a2enmod rewrite headers
sudo systemctl restart apache2
```

### B. Deploy Modern Zaqar

```bash
# Create web directory
sudo mkdir -p /var/www/html/modern-zaqar

# Clone repository (replace with actual repository URL)
sudo git clone https://github.com/yourusername/modern-zaqar.git /var/www/html/modern-zaqar

# Install Composer
curl -sS https://getcomposer.org/installer | sudo php -- --install-dir=/usr/local/bin --filename=composer

# Install dependencies
cd /var/www/html/modern-zaqar
sudo composer install --no-dev

# Set permissions
sudo chmod -R 755 /var/www/html/modern-zaqar
sudo chmod -R 777 /var/www/html/modern-zaqar/logs /var/www/html/modern-zaqar/uploads
sudo chown -R www-data:www-data /var/www/html/modern-zaqar
```

### C. Configure SMTP (Recommended)

Edit the config.php file to set up your SMTP settings:

```bash
sudo nano /var/www/html/modern-zaqar/config.php
```

Update the following settings:

```php
'send_method' => 'smtp',  // Change from 'mail' to 'smtp'
'smtp' => [
    'host' => 'smtp.example.com',  // Change to your SMTP server
    'port' => 587,                 // Change if needed
    'username' => 'your_username', // Your SMTP username
    'password' => 'your_password', // Your SMTP password
    'encryption' => 'tls',         // Usually 'tls' or 'ssl'
]
```

## Access Modern Zaqar

Open your web browser and navigate to:

```
http://YOUR_SERVER_IP/modern-zaqar/
```

You should see the Modern Zaqar interface. Log in with the default credentials:

- Username: admin
- Password: admin

**Important**: Change the default password immediately after first login!

## Quick Spoofing Test

1. On the dashboard, click "New Email" or navigate to the "Spoof Email" tab
2. Fill in the required fields:
   - From Name: The name to display to recipients
   - From Email: The email address you want to spoof
   - To Email: Your test recipient email
   - Subject: Test subject
   - Message: Test message
3. Optional: Use the "Domain Security Analyzer" button to check if the domain is spoofable
4. Click "Send Email"
5. Check the recipient's inbox for the spoofed email

## Troubleshooting

### Emails Not Sending

Check the logs for errors:

```bash
sudo cat /var/www/html/modern-zaqar/logs/app.log
```

### 500 Internal Server Error

Check Apache error logs:

```bash
sudo cat /var/log/apache2/error.log
```

Check file permissions:

```bash
sudo chmod -R 777 /var/www/html/modern-zaqar/logs /var/www/html/modern-zaqar/uploads
```

## Next Steps

For more detailed information, refer to:

- [Installation Guide](INSTALLATION_GUIDE.md)
- [Domain Analysis Guide](DOMAIN_ANALYSIS_GUIDE.md)

## ⚠️ Legal Warning

Modern Zaqar is provided for **EDUCATIONAL PURPOSES ONLY**. Email spoofing without explicit permission is illegal in most jurisdictions. Only use this tool in authorized testing environments or with explicit permission from all parties involved.

---

_For more help, visit the issues section of the repository._
