# Debugging Notes for Modern Zaqar

This document contains notes and information to help troubleshoot common issues with Modern Zaqar.

## Recent Fixes

### 1. Duplicate Function Declarations

Fixed multiple issues with duplicate function declarations:

- `send_spoofed_email()` was declared in both `index.php` and `includes/mailer.php`
- `log_message()` was declared twice in `includes/utils.php`
- `analyze_domain_security()` was being redeclared in `includes/analyzer.php`

Solution: Ensured all functions are wrapped in `if (!function_exists())` checks and removed duplicate declarations.

### 2. CSRF Token Validation Issues

Fixed problems with CSRF token validation for AJAX requests:

- Ensured the form name used to generate tokens matches the form name used in the validation
- Added proper `form_name` hidden input to forms
- Updated the AJAX request handler to properly handle different form names
- Added debugging logs to trace token generation and validation

### 3. Autoloading Conflicts

Fixed issues where files were being included both via `require_once` and Composer's autoloader:

- Removed duplicate entries from Composer's autoloader
- Ensured all required files use the proper paths

### 4. Debug Mode and Logging

Enhanced error logging and debugging:

- Added debug mode toggle in config.php
- Created a logs directory with proper permissions
- Added more explicit error logging throughout the codebase
- Added console.log statements in JavaScript for frontend debugging

## Common Issues and Solutions

### 1. Server Returns 500 Internal Server Error

Possible causes:

- PHP syntax errors
- Missing required extensions
- Incorrect file permissions
- Duplicate function declarations

Solution:

- Check PHP error logs at `/var/log/apache2/error.log` or `logs/php_errors.log`
- Ensure all required PHP extensions are installed
- Check file permissions (should be readable by web server)

### 2. CSRF Token Validation Failed

Possible causes:

- Token not generated properly
- Mismatch between form name in generation and validation
- Token not included in AJAX request

Solution:

- Verify that CSRF tokens are generated with the correct form name
- Ensure the token is included in all AJAX requests
- Check that the form contains a hidden input with the token

### 3. Emails Not Sending

Possible causes:

- Incorrect SMTP settings
- PHP mail() not configured properly
- Server blocking outgoing mail

Solution:

- Verify SMTP credentials
- Ensure PHP mail() is enabled in php.ini
- Check server firewall settings for outgoing SMTP traffic
- Try sending mail with a different method

## Testing Tips

1. Use `error_log()` to debug PHP issues
2. Add `console.log()` statements to JavaScript for frontend debugging
3. Check browser console for JavaScript errors and AJAX request details
4. Use browser developer tools to inspect network requests and responses
5. Try testing with a simpler form before tackling complex features

## Docker Specific Issues

1. If making changes, remember to rebuild the container with `docker-compose down && docker-compose build && docker-compose up -d`
2. Check Docker logs with `docker logs modern-zaqar`
3. Shell into the container to debug with `docker exec -it modern-zaqar bash`
4. Ensure the Docker volume mounts are correctly configured

## PHP Version and Extension Requirements

Modern Zaqar requires:

- PHP 8.0 or higher
- Extensions: json, fileinfo, curl
- Composer for dependency management

## Recommendations for Future Refactoring

1. **Move to a Class-Based Architecture**:

   - Convert utility functions to static methods in classes
   - Implement namespaces for better organization
   - Use dependency injection for services

2. **Improve Error Handling**:

   - Implement comprehensive try/catch blocks
   - Create a centralized error handler

3. **Apply Security Enhancements**:
   - Use prepared statements for any database queries
   - Implement Content Security Policy headers
   - Add rate limiting for sensitive operations
